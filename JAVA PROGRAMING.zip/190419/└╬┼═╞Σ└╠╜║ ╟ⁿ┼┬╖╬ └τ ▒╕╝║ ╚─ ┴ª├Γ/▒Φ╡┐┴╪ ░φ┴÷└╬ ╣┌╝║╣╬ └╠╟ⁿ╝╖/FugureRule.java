
public interface FugureRule {
	public abstract void inputValue();
	public abstract void cal();
}
