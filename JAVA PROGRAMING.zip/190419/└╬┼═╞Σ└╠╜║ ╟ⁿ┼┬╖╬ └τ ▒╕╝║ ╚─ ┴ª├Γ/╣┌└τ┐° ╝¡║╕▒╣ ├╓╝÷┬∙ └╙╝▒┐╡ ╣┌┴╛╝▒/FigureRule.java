
public interface FigureRule {

	public void inputValue();
	public void printResult();

}
