
public class Figure implements FigureRule {

	String name = "도형 넓이 구하기";
	int selectNum=0;
	int side1=0;
	int side2=0;
	int height=0;
	double area=0;
	
	public void inputValue(){		
	}
	
	public void printResult() {
	}


}
