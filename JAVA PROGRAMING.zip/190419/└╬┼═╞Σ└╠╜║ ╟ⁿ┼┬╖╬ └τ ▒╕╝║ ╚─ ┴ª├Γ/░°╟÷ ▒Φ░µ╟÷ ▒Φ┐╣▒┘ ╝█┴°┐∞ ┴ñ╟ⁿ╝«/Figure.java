public interface Figure {
	public void inputValue();
	public void printResult();
}
