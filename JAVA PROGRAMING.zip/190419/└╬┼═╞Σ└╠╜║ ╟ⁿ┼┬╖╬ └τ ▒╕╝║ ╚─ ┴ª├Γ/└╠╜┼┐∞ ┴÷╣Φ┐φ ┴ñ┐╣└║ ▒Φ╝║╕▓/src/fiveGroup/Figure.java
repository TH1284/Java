package fiveGroup;

public interface Figure {
	
}
