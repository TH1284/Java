

public interface Figure {
	public void printResult(); 
	public void inputValue();
}
