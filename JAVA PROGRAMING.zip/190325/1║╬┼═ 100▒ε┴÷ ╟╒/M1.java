
public class M1 {
	public static void main(String[] args) {
		TotalNumber t1 = new TotalNumber();
		t1.doTotal();
	}
}
