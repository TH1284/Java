
public class ObjectTest {
	public static void main(String[] args) {
		
	}
}
