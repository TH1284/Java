
public class M1 {
	public static void main(String[] args) {
		PrimeNumber p1 = new PrimeNumber();
		p1.doCheck();
	}
}
