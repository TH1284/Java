
public class Check1 {
	public boolean doCheck(int number1) {
		if (number1 % 6 == 0) {
//			System.out.println("" + number1 + "은 6의 배수입니다.");
			return true;
		} else {
//			System.out.println("" + number1 + "은 6의 배수가 아닙니다.");
			return false;
		}
	}
}
