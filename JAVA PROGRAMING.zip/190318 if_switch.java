import java.util.Random;

public class Test11 {
	public static void main(String[] args) {
		Random randNumber = new Random();

		int r1 = randNumber.nextInt(6) + 1;

		if (r1 == 1) {
			System.out.println("�۸�");
		} else if (r1 == 2) {
			System.out.println("�߿�");
		} else if (r1 == 3) {
			System.out.println(3);
		} else if (r1 == 4) {
			System.out.println(4);
		} else if (r1 == 5) {
			System.out.println(5);
		} else {
			System.out.println(6);
		}

		switch (r1) {
		case 1:
			System.out.println("�۸�");
			break;
		case 2:
			System.out.println("�߿�");
			break;
		case 3:
			System.out.println(3);
			break;
		case 4:
			System.out.println(4);
			break;
		case 5:
			System.out.println(5);
			break;
		default:
			System.out.println(6);
		}
	}
}
