
public class java0318_00 {
	public static void main(String[] args) {
		int a ;
		int b ;
		int c;
		
		
		

}
}