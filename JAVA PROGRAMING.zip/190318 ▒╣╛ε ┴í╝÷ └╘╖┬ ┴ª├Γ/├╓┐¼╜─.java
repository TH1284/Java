import java.util.Scanner;

public class Cys03 {
	public static void main(String[] args) {
		
		int kor1;
		int kor2;
		int kor3;
		
					
		Scanner s=new Scanner(System.in);