import java.util.Random;

public class Test12 {
	public static void main(String[] args) {
		int a;
		int b;
		int c;
		
		Random score = new Random();
		a = score.nextInt(100);
		b = score.nextInt(100);
		c = score.nextInt(100);
		
		if (a== b
}
	
}

	   