
import java.util.Scanner;
public class Test4 {

	public static void main(String[] args) {
		
		
		int num[] num int[5];
		Scanner scan = new Scanner(System.in);
		System.out.println ("점수를 입력하세요");
		
		for (int i = 0; i < num length; i++) {
		for (int j = i+1; j < num length; j++) {
		for (int k = j+1; k < num length; k++) {
				
			if {(num[i] < num[j]) 
			 int num [j]; 
		} if { (num[i] ==  num[j]) 
		  int num [i]; 
		} if {(num[j] < num[k]) 
		    	int num [k];} 
		
					// for문으로 하려다가 망했어요 :(
		
		}

	
		}

