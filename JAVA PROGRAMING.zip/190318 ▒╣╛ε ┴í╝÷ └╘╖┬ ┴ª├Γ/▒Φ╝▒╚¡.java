import java.util.Scanner;

public class For_1 {
public static void main(String[] args) {
	
int rank = newint();
	for ( int i=0; i<4; i++) {
		System.out.println("���� ������ �Է��� �ּ���");
		Scanner d =new Scanner(System.in);
		int inputNumber = d.nextInt();
		rank(i) = 1;
	}
     for (int i=0 ; i<4; i++) {
		for(int j=0;j<4; j++) {
			if(inputNumber(i) < inputNumber(int j));
			    inpurNumber(i) = inputNumber(j)+1;
		System.out.println(i);
		}	
		}

	
}
}
