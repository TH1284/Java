public class RunClass {
	public static void main(String[] args) {
		Student s1;
		Student[] sArray = new Student[10];

		s1 = new Student();
		sArray[0] = new Student();

		s1.korScore = 10;
		sArray[0].korScore = 10;
	}
}
