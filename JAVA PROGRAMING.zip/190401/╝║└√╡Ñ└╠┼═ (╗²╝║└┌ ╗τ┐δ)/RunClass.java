
public class RunClass {
	public static void main(String[] args) {
		Student3 s3 = new Student3("�Ӳ���", 10, 20, 10);
		
//		s3.name = "�Ӳ���";
//		s3.korScore = 10;
//		s3.engScore = 20;
//		s3.mathScore = 10;
	
	
	
	
	
	
	}
}
