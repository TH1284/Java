
public class Student3 {
	String name;
	int korScore;
	int engScore;
	int mathScore;
	
	Student3(String name, int korScore, int engScore, int mathScore) {
		this.name = name;
		this.korScore = korScore;
		this.engScore = engScore;
		this.mathScore = mathScore;
	}
}
