
public class Student {
	public String name;
	int korScore;
	int engScore;
	int mathScore;
	String memo;
}
