
public abstract class Figure {
	String name = "도형 넓이 구하기";
	public abstract void inputValue();
	public void printResult() {
		System.out.println(this.name);
	}
}
