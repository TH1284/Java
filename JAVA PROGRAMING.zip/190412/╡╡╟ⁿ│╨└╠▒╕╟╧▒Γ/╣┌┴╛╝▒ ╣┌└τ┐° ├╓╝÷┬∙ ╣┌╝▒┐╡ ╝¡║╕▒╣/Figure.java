
public abstract class Figure {
	String name;
	int side1;
	int side2;
	int height;
	double area;
	
	public abstract void inputVal();
	
	public void printResult() {
		System.out.println();
	}

}
