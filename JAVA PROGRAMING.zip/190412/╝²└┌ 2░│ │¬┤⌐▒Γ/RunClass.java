
public class RunClass {
	public static void main(String[] args) {
		Div div = new Div();
		div.inputNumber();
		div.printResult();
	}
}
