
public class RunClass {
	public static void main(String[] args) {
		Kaufu kaufu = new Kaufu();
		kaufu.inputData();
		kaufu.result();
	}
}
